score = 0

score += 1

print(score)
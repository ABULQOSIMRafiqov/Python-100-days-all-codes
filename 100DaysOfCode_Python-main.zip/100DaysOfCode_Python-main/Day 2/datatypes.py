mystery = 378_695.24
print(type(mystery))
# with open("my_file.txt") as file:
#     contents = file.read()
#     print(contents)

with open("new_my_file.txt", mode="w") as file:
    file.write("New text.")
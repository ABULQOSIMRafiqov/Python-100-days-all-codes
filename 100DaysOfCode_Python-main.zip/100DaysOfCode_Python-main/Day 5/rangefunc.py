for number in range(1,10,3):
    print(number)
print("Welcome to the Band Name Generator")

city = input("What's name of the city you grew up in?\n")
petName = input("What's your pet's name?\n")

print("Your band name could be " + city + " " + petName)